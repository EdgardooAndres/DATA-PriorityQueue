package priorityQueueInterfaces;

public interface Entry<K, V> {
	K getKey(); 
	V getValue(); 
}
