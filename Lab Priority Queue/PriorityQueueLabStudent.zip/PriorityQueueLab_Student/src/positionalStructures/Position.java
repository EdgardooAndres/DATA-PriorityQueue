package positionalStructures;

public interface Position<E> {
	E getElement(); 
}
